package application;

import java.util.ArrayList;

import javafx.beans.property.StringProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;

public class PizzaOrderController {
	
    private String sizeChoice = "Small";
    private String cheeseChoice = "Single";
    private String pineappleChoice = "None";
    private String greenPepperChoice = "None";
    private String hamChoice = "Single";

    private int numPizzas;
    private ArrayList<LineItem> order = new ArrayList<LineItem>();
    private Pizza p;

    @FXML
    private RadioButton NoHam;

    //FX ids for the toggle groups
    @FXML
    private ToggleGroup size;

    @FXML
    private ToggleGroup cheese;

    @FXML
    private ToggleGroup pineapple;

    @FXML
    private ToggleGroup greenpepper;

    @FXML
    private ToggleGroup ham;
    
    @FXML
    private RadioButton greenpeppersingle;

    @FXML
    private RadioButton nogreenpepper;

    @FXML
    private RadioButton pineapplesingle;

    @FXML
    private RadioButton nopineapple;
    
    @FXML
    private TextArea errormessage;

    @FXML
    private TextArea ordermessage;

    @FXML
    private TextArea costPizza;
    
    @FXML
    private TextField inputpizza;

    @FXML
    private TextArea addpizza;    
    
    @FXML
    void initialize() {
    	
        size.selectedToggleProperty().addListener((ov, old_toggle, new_toggle) -> {
            sizeChoice = ((RadioButton) new_toggle).getText();
        });

        cheese.selectedToggleProperty().addListener((ov, old_toggle, new_toggle) -> {
            cheeseChoice = ((RadioButton) new_toggle).getText();
        });

        pineapple.selectedToggleProperty().addListener((ov, old_toggle, new_toggle) -> {
            pineappleChoice = ((RadioButton) new_toggle).getText();
        });


        greenpepper.selectedToggleProperty().addListener((ov, old_toggle, new_toggle) -> {
            greenPepperChoice = ((RadioButton) new_toggle).getText();
        });

        ham.selectedToggleProperty().addListener((ov, old_toggle, new_toggle) -> {
            hamChoice = ((RadioButton) new_toggle).getText();
        });
        
        //Restrict the entry of a text box to just integers
        inputpizza.textProperty().addListener((observableValue, oldText, newText) ->
    	{
    		if (newText != null && !newText.isEmpty()) {
	    		try {
	    			int aVal = Integer.parseInt(newText);
	    		} catch (NumberFormatException e) {
	    			((StringProperty)observableValue).setValue(oldText);
	    		}
    		}
    	});
    }

    // Calculates the cost of the pizza configured
    @FXML
    void pizzaCost(ActionEvent event) throws IllegalPizza {
        p = new Pizza(sizeChoice, cheeseChoice, pineappleChoice, greenPepperChoice, hamChoice);
        costPizza.setText("$" + p.getCost());
    }

    // Disable pineapple and green pepper when ham is not selected
    @FXML
    void disableToppings(ActionEvent event) throws IllegalPizza {
        pineapplesingle.setDisable(true);
        pineapple.selectToggle(nopineapple);

        greenpeppersingle.setDisable(true);
        greenpepper.selectToggle(nogreenpepper);
        pizzaCost(event);
    }

    // Enable the pineapple and green pepper options when ham is selected
    @FXML
    void enableToppings(ActionEvent event) throws IllegalPizza {
        pineapplesingle.setDisable(false);
        greenpeppersingle.setDisable(false);
        pizzaCost(event);
    }

    //Displays the cost of the line item when click enter button
    @FXML
    void numPizzaEntered(ActionEvent event) throws IllegalPizza {
        errormessage.clear();
        try {
            numPizzas = Integer.parseInt(inputpizza.getText());
        } catch (NumberFormatException e) {
            errormessage.setText("Invalid entry!");
            return;
        }
        p = new Pizza(sizeChoice, cheeseChoice, pineappleChoice, greenPepperChoice, hamChoice);
        LineItem item;
        try {
            item = new LineItem(numPizzas, p);
            if (numPizzas == 1)
                costPizza.setText(numPizzas + " Pizza Selected");
            else
                costPizza.setText(numPizzas + " Pizzas Selected");
            inputpizza.clear();
            costPizza.setText("Total Cost: $" + item.getCost());
        } catch (Exception e) {
            errormessage.setText("Invalid entry!");
        }
    }

    //Creates a lineitem and display it
    @FXML
    void addToLineItem(ActionEvent event) throws IllegalPizza {
        try {
            p = new Pizza(sizeChoice, cheeseChoice, pineappleChoice, greenPepperChoice, hamChoice);
            LineItem item = new LineItem(numPizzas, p);
            errormessage.clear();
            order.add(item);
            printLine(order);
        } catch (IllegalPizza e) {
            String[] error = e.toString().split(":");
            errormessage.appendText(error[1] + '\n');
        }
    }

    //Prints the order to the textarea
    void printLine(ArrayList<LineItem> list) {
        int counter = 0;
        double totalCost = 0;
        addpizza.clear();
        addpizza.setText("Pizza Order:\n");
        for(LineItem item : list) {
            counter++;
            addpizza.appendText(counter + ".	" + item.toString() +'\n');
            totalCost += item.getCost();
        }
        addpizza.appendText("Total Cost of Order: $" + Math.round(totalCost*100.0)/100.0);
    }


}
